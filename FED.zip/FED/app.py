import streamlit as st
import cv2
from tensorflow.keras.models import load_model
import numpy as np

model = load_model("emotion_detection_model.keras")
categories = ['angry', 'fear', 'disgust', 'happy', 'neutral', 'sad', 'surprise']

def predict_emotion(frame):
    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    resized_frame = cv2.resize(gray_frame, (48, 48))
    processed_frame = np.expand_dims(resized_frame, axis=(0, -1)) / 255.0
    prediction = model.predict(np.expand_dims(processed_frame, axis=0))
    return categories[np.argmax(prediction)]

st.title("Real-Time Emotion Detection")

run = st.checkbox("Run Webcam")
FRAME_WINDOW = st.image([])

cap = cv2.VideoCapture(0)
while run:
    ret, frame = cap.read()
    if not ret:
        st.write("Failed to grab frame.")
        break

    emotion = predict_emotion(frame)
    st.text(f"Emotion: {emotion}")
    FRAME_WINDOW.image(frame, channels="BGR")

cap.release()
